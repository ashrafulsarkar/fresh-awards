# Event Voting System

## Description
A WordPress plugin that enables event voting functionality for your website.

## Installation
1. Upload the `event-voting-system` folder to `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'Event Voting System' settings in your WordPress admin panel

## Usage
1. Create a new event:
    - Navigate to Events > Add New
    - Set event details, voting options, and duration
    - Publish the event

2. Managing votes:
    - View vote counts in the Events dashboard
    - Export voting results as CSV
    - Monitor voting activity in real-time

## Shortcodes
- `[event_voting_form id="event_id"]` - Display voting form for specific event

## Requirements
- WordPress 5.0 or higher
- PHP 7.2 or higher

## Support
For support queries, please create an issue in the plugin's repository.
