<?php
function evs_create_tables() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();

	// Voting Forms table
	$sql1 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}evs_voting_forms (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        form_name varchar(255) NOT NULL,
        message_lavel TEXT NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

	// Voting Options table
	$sql2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}evs_voting_options (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        form_id mediumint(9) NOT NULL,
        company_name varchar(255) NOT NULL,
        company_logo varchar(255) NOT NULL,
        PRIMARY KEY  (id),
        FOREIGN KEY  (form_id) REFERENCES {$wpdb->prefix}evs_voting_forms(id) ON DELETE CASCADE
    ) $charset_collate;";

	// Submitted Votes table
	$sql3 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}evs_submitted_votes (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        form_id mediumint(9) NOT NULL,
        option_id mediumint(9) NOT NULL,
        user_email varchar(255) NOT NULL,
        vote_reason text NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        FOREIGN KEY  (form_id) REFERENCES {$wpdb->prefix}evs_voting_forms(id) ON DELETE CASCADE,
        FOREIGN KEY  (option_id) REFERENCES {$wpdb->prefix}evs_voting_options(id) ON DELETE CASCADE
    ) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql1 );
	dbDelta( $sql2 );
	dbDelta( $sql3 );
}