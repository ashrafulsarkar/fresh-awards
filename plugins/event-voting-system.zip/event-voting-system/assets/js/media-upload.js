jQuery(document).ready(function($) {
    // Media uploader
    function initMediaUploader(button) {
        button.click(function(e) {
            e.preventDefault();
            var button = $(this);
            var customUploader = wp.media({
                title: 'Select Company Logo',
                library: {
                    type: 'image'
                },
                button: {
                    text: 'Use this image'
                },
                multiple: false
            }).on('select', function() {
                var attachment = customUploader.state().get('selection').first().toJSON();
                button.siblings('.company-logo-url').val(attachment.url);
                button.siblings('.company-logo-preview').attr('src', attachment.url).show();
            }).open();
        });
    }

    // Initialize media uploader for existing and new company options
    function initializeCompanyOption($option) {
        initMediaUploader($option.find('.upload-logo-btn'));
        
        // Delete company option
        $option.find('.delete-company').click(function() {
            if($('.company-option').length > 1) {
                $(this).closest('.company-option').remove();
            } else {
                alert('You must have at least one company option.');
            }
        });
    }

    // Initialize existing company options
    $('.company-option').each(function() {
        initializeCompanyOption($(this));
    });

    // Add new company option
    $('#add-company-option').click(function() {
        var newOption = `
            <div class="company-option">
                <div class="company-header">
                    <h4>Company Option</h4>
                    <button type="button" class="delete-company button button-link-delete">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                </div>
                <p>
                    <label>Company Name:</label>
                    <input type="text" name="company_name[]" required class="regular-text">
                </p>
                <p>
                    <label>Company Logo:</label>
                    <input type="hidden" name="company_logo[]" class="company-logo-url" required>
                    <img src="" class="company-logo-preview" style="display:none; max-width:200px; margin-top:10px;">
                    <button type="button" class="upload-logo-btn button">Upload Logo</button>
                </p>
            </div>
        `;
        
        var $newOption = $(newOption);
        $('#company-options').append($newOption);
        initializeCompanyOption($newOption);
    });

    // Add new company option
    $('#create-new-form').click(function () {
        $('#postbox').toggle();
    });
});