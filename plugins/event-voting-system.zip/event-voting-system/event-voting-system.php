<?php
/**
 * Plugin Name: Event Voting System
 * Plugin URI: https://github.com/ashrafulsarkar/event-voting-system
 * Description: A plugin to create and manage voting forms for events.
 * Version: 1.0.1
 * Author: Ashraful Sarkar Naiem
 * Author URI: https://www.linkedin.com/in/ashrafulsarkar/
 * Text Domain: event-voting-system
 * Domain Path: /languages
 * License: GPL3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'WP_EVENT_VOTING_PATH', plugin_dir_path( __FILE__ ) );
define( 'WP_EVENT_VOTING_URL', plugin_dir_url( __FILE__ ) );

// Include activation file.
require_once WP_EVENT_VOTING_PATH . 'activation.php';

// Plugin activation hook
register_activation_hook( __FILE__, 'evs_create_tables' );

require_once WP_EVENT_VOTING_PATH . 'includes/class-event-voting-admin.php';
require_once WP_EVENT_VOTING_PATH . 'includes/class-event-voting-frontend.php';

// Initialize the plugin.
function event_voting_init() {
	new Event_Voting_Admin();
	new Event_Voting_Frontend();
}
add_action( 'plugins_loaded', 'event_voting_init' );