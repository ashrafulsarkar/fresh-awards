<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Event_Voting_Admin {

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'evs_admin_menu' ] );
		add_action( 'admin_init', [ $this, 'handle_csv_export' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'evs_admin_scripts' ] );
	}

	public function evs_admin_menu() {
		add_menu_page(
			'Event Voting System',
			'Event Voting',
			'manage_options',
			'event-voting-system',
			[ $this, 'evs_dashboard_page' ],
			'dashicons-chart-bar',
			5
		);

		add_submenu_page(
			'event-voting-system',
			'Dashboard',
			'Dashboard',
			'manage_options',
			'event-voting-system',
			[ $this, 'evs_dashboard_page' ]
		);

		add_submenu_page(
			'event-voting-system',
			'Submitted Votes',
			'Submitted Votes',
			'manage_options',
			'evs-submitted-votes',
			[ $this, 'evs_submitted_votes_page' ]
		);

		add_submenu_page(
			'event-voting-system',
			'Voting Options',
			'Voting Options',
			'manage_options',
			'evs-voting-options',
			[ $this, 'evs_voting_options_page' ]
		);
	}

	public function evs_dashboard_page() {
		require_once WP_EVENT_VOTING_PATH . 'includes/views/dashboard.php';
	}

	public function evs_submitted_votes_page() {
		require_once WP_EVENT_VOTING_PATH . 'includes/views/submitted_votes.php';
	}

	public function evs_voting_options_page() {
		require_once WP_EVENT_VOTING_PATH . 'includes/views/voting_options.php';
	}

	public function evs_admin_scripts( $hook ) {
		if ( strpos( $hook, 'evs-voting-options' ) !== false ) {
			wp_enqueue_media();
			wp_enqueue_script( 'evs-media-upload', WP_EVENT_VOTING_URL . 'assets/js/media-upload.js', array( 'jquery' ), '1.0', true );
		}
		if ( strpos( $hook, 'event-voting' ) === false ) {
			return;
		}
		wp_enqueue_style( 'evs-admin-style', WP_EVENT_VOTING_URL . 'assets/css/admin-style.css' );
	}

	public function handle_csv_export() {
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'evs-submitted-votes'
			&& isset( $_GET['export_csv'] ) && isset( $_GET['form_id'] ) ) {

			// Verify nonce
			if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'export_csv_' . $_GET['form_id'] ) ) {
				wp_die( 'Invalid nonce' );
			}

			// Handle CSV export
			global $wpdb;

			$form_id = intval( $_GET['form_id'] );

			// Get form name
			$form_name = $wpdb->get_var( $wpdb->prepare(
				"SELECT form_name FROM {$wpdb->prefix}evs_voting_forms WHERE id = %d",
				$form_id
			) );

			// Get votes
			$votes = $wpdb->get_results( $wpdb->prepare(
				"SELECT sv.*, vo.company_name, f.form_name 
                FROM {$wpdb->prefix}evs_submitted_votes sv
                JOIN {$wpdb->prefix}evs_voting_options vo ON sv.option_id = vo.id
                JOIN {$wpdb->prefix}evs_voting_forms f ON sv.form_id = f.id
                WHERE sv.form_id = %d",
				$form_id
			) );

			// Set headers
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $form_name . '-votes.csv' ) . '"' );
			header( 'Pragma: no-cache' );
			header( 'Expires: 0' );

			// Create output
			$output = fopen( 'php://output', 'w' );

			// Add UTF-8 BOM
			fputs( $output, "\xEF\xBB\xBF" );

			// Add headers
			fputcsv( $output, array( 'SL', 'Company', 'Email', 'Why you voted?', 'Date' ) );

			// Add data
            $i = 1;
			foreach ( $votes as $vote ) {
				fputcsv( $output, array(
					$i++,
					$vote->company_name,
					$vote->user_email,
					$vote->vote_reason,
					$vote->created_at
				) );
			}

			fclose( $output );
			exit();
		}
	}
}