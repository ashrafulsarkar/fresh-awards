<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Event_Voting_Frontend {

	public function __construct() {
		add_shortcode( 'event_voting_form', [ $this, 'evs_voting_form_shortcode' ] );
		add_action( 'wp_ajax_submit_vote', [ $this, 'evs_submit_vote_ajax' ] );
		add_action( 'wp_ajax_nopriv_submit_vote', [ $this, 'evs_submit_vote_ajax' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );
	}

	public function evs_voting_form_shortcode( $atts ) {
		global $wpdb;

		$atts = shortcode_atts( array(
			'id' => 0
		), $atts );
		
		$form_id = intval( $atts['id'] );
		$form    = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}evs_voting_forms WHERE id = %d",
			$form_id
		) );

		if ( ! $form ) {
			return '<p>Voting form not found.</p>';
		}

		$options = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}evs_voting_options WHERE form_id = %d",
			$form_id
		) );

		ob_start();
		?>
		<div class="event-voting">
			<form method="post" id="voting-form-<?php echo $form_id; ?>" class="event-voting-form">
				<input type="hidden" name="form_id_<?php echo $form_id; ?>" value="<?php echo $form_id; ?>">
				<?php wp_nonce_field( 'vote_submission', "vote_nonce_$form_id" ); ?>
				<div class="voting-options" id="voting-options-<?php echo $form_id; ?>">
					<?php foreach ( $options as $option ) : ?>
						<div class="voting-option">
							<label>
								<img src="<?php echo esc_url( $option->company_logo ); ?>"
								alt="<?php echo esc_attr( $option->company_name ); ?>">
								<div>
									<input type="radio" name="option_id" value="<?php echo $option->id; ?>" required>
									<span><?php echo esc_html( $option->company_name ); ?></span>
								</div>
							</label>
						</div>
					<?php endforeach; ?>
				</div>
				<p class="error-message" id="error-vote-<?php echo $form_id; ?>" style="display: none;">This is required. Please select one for vote.</p>

				<div class="voter-info">
					<p>
						<label for="vote-reason-<?php echo $form_id; ?>" class="vote_reason"><?php echo $form->message_lavel;?></label>
						<textarea name="reason" id="vote-reason-<?php echo $form_id; ?>" placeholder="Other - Maximum 100 characters"></textarea>
						<p class="error-message" id="warning-message-<?php echo $form_id; ?>" style="display: none;">Text will be maximum 100 characters.</p>
					</p>
                    <h4>YOUR DETAILS</h4>
                    <p>
						<label for="voter-email-<?php echo $form_id; ?>" class="voter_email">Email * Only one vote per unique email address accepted</label>
						<input type="email" name="email" id="voter-email-<?php echo $form_id; ?>" placeholder="Place your EMAIL address here" required>
						<p class="error-message" id="error-message-<?php echo $form_id; ?>" style="display: none;">This is required field. Please enter your email address.</p>
                        <span>* Mandatory Fields</span>
					</p>
				</div>

				<input type="submit" name="submit_vote" id="submit_vote_<?php echo $form_id; ?>" value="Submit Your Vote">
				<p class="error-message" id="error-other-<?php echo $form_id; ?>" style="display: none;"></p>
			</form>
			<script>
				jQuery(document).ready(function ($) {
					$('#voting-form-<?php echo $form_id; ?>').on('submit', function (e) {
						e.preventDefault();

						// Validate form
						const checkedOption = $('#voting-options-<?php echo $form_id; ?> input[name="option_id"]:checked').val();
						const email = $('#voter-email-<?php echo $form_id; ?>').val();
						const reason = $('#vote-reason-<?php echo $form_id; ?>').val();

						if (!checkedOption) {
							$('#error-vote-<?php echo $form_id; ?>').show();
							return;
						}else{
							$('#error-vote-<?php echo $form_id; ?>').hide();
						}

						if (reason.length > 100) {
							$('#warning-message-<?php echo $form_id; ?>').show();
                            return;
                        }else{
							$('#warning-message-<?php echo $form_id; ?>').hide();
						}

						if (!email) {
							$('#error-message-<?php echo $form_id; ?>').show();
							return;
						}else{
							$('#error-message-<?php echo $form_id; ?>').hide();
						}
						// Disable submit button
						const submitBtn = $('#submit_vote_<?php echo $form_id; ?>');
						submitBtn.prop('disabled', true).val('Please wait...');
						
						// Submit form via AJAX
						$.ajax({
							url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
							type: 'POST',
							data: {
								action: 'submit_vote',
								nonce: $('#vote_nonce_<?php echo $form_id;?>').val(),
								form_id: $('input[name="form_id_<?php echo $form_id; ?>"]').val(),
								option_id: checkedOption,
								email: email,
								reason: reason
							},
							success: function (response) {
								if (response.success) {
									$('#voting-form-<?php echo $form_id; ?>').html('<div class="vote-success"><h3><?php echo esc_html( $form->form_name ); ?></h3><p>Thank You For Your Entry.</p><p>Your Submission Has Been Received!</p></div>');
									$('.vote_hide_<?php echo $form_id; ?>').hide();
								} else {
									// console.log(response.data);
									$('#error-other-<?php echo $form_id; ?>').text(response.data).show();
									setTimeout(function(){
										$('#error-other-<?php echo $form_id; ?>').hide();
									}, 3000);
									submitBtn.prop('disabled', false).val('Submit Your Vote');
								}
							},
							error: function () {
								// console.log('Error submitting vote. Please try again.');
								$('#error-other-<?php echo $form_id; ?>').text('Error submitting vote. Please try again.').show();
								setTimeout(function(){
									$('#error-other-<?php echo $form_id; ?>').hide();
								}, 3000);
								submitBtn.prop('disabled', false).val('Submit Your Vote');
							}
						});
					});
				});
			</script>
		</div>

		<?php
		return ob_get_clean();
	}

	public function evs_submit_vote_ajax() {
		global $wpdb;

		// Verify nonce
		check_ajax_referer( 'vote_submission', 'nonce' );

		$form_id   = intval( $_POST['form_id'] );
		$option_id = intval( $_POST['option_id'] );
		$email     = sanitize_email( $_POST['email'] );
		$reason    = sanitize_textarea_field( $_POST['reason'] );

		// Check for existing vote
		$existing_vote = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}evs_submitted_votes 
            WHERE form_id = %d AND user_email = %s",
			$form_id, $email
		) );

		if ( $existing_vote ) {
			wp_send_json_error( 'You have already voted in this form.' );
			return;
		}

		// Insert vote
		$result = $wpdb->insert(
			$wpdb->prefix . 'evs_submitted_votes',
			array(
				'form_id'     => $form_id,
				'option_id'   => $option_id,
				'user_email'  => $email,
				'vote_reason' => $reason
			)
		);

		if ( $result ) {
			wp_send_json_success( 'Thank you for voting!' );
		} else {
			wp_send_json_error( 'Error submitting vote. Please try again.' );
		}
		wp_die();
	}

	public function enqueue_frontend_scripts() {
		wp_enqueue_style( 'event-voting', WP_EVENT_VOTING_URL . 'assets/css/style.css' );
	}
}