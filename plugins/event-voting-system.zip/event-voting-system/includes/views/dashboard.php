<?php
global $wpdb;

$forms = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}evs_voting_forms" );
?>
<div class="wrap">
	<h1>Event Voting System - Dashboard</h1>
	<?php foreach ( $forms as $form ) : ?>
		<div class="postbox">
			<h2><?php echo esc_html( $form->form_name ); ?></h2>
			<?php
			$results = $wpdb->get_results( $wpdb->prepare(
				"SELECT vo.company_name, vo.company_logo, COUNT(sv.id) as vote_count 
                FROM {$wpdb->prefix}evs_voting_options vo 
                LEFT JOIN {$wpdb->prefix}evs_submitted_votes sv ON vo.id = sv.option_id 
                WHERE vo.form_id = %d 
                GROUP BY vo.id 
                ORDER BY vote_count DESC",
				$form->id
			) );
			?>
			<table class="widefat">
				<thead>
					<tr>
                        <th>SL</th>
						<th>Company</th>
						<th>Votes</th>
					</tr>
				</thead>
				<tbody>
					<?php
                    $i = 1;
                    foreach ( $results as $result ) : ?>
						<tr>
                            <td><?php echo $i++; ?></td>
							<td><?php echo esc_html( $result->company_name ); ?></td>
							<td><?php echo esc_html( $result->vote_count ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endforeach; ?>
</div>