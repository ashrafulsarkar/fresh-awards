<?php
global $wpdb;
$forms = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}evs_voting_forms" );
?>
<div class="wrap">
	<h1>Submitted Votes</h1>

	<?php foreach ( $forms as $form ) : ?>
		<div class="postbox">
			<h2 class="submitted_title">
				<?php echo esc_html( $form->form_name ); ?>
				<a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=evs-submitted-votes&export_csv=1&form_id=' . $form->id ), 'export_csv_' . $form->id ); ?>"
					class="button button-primary">Export CSV</a>
			</h2>
			<?php
			$votes = $wpdb->get_results( $wpdb->prepare(
				"SELECT sv.*, vo.company_name 
                FROM {$wpdb->prefix}evs_submitted_votes sv
                JOIN {$wpdb->prefix}evs_voting_options vo ON sv.option_id = vo.id
                WHERE sv.form_id = %d
                ORDER BY sv.created_at DESC",
				$form->id
			) );
			?>
			<table class="widefat">
				<thead>
					<tr>
                        <th>SL</th>
						<th>Company</th>
						<th>Email</th>
						<th>Why you voted?</th>
						<th>Date</th>
					</tr>
				</thead>
				<tbody>
					<?php
                    $i = 1;
                    foreach ( $votes as $vote ) : ?>
						<tr>
                            <td><?php echo $i++; ?></td>
							<td><?php echo esc_html( $vote->company_name ); ?></td>
							<td><?php echo esc_html( $vote->user_email ); ?></td>
							<td><?php echo esc_html( $vote->vote_reason ); ?></td>
							<td><?php echo esc_html( $vote->created_at ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endforeach; ?>
</div>