<?php
global $wpdb;

// Handle form submission
if ( $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['create_form'] ) ) {
	$form_name = sanitize_text_field( $_POST['form_name'] );
	$message_lavel = sanitize_text_field( $_POST['message_lavel'] );
	$wpdb->insert(
		$wpdb->prefix . 'evs_voting_forms',
		array( 
            'form_name' => $form_name,
            'message_lavel' => $message_lavel
        )
	);
	$form_id = $wpdb->insert_id;

	// Handle company options
	foreach ( $_POST['company_name'] as $key => $name ) {
		$logo = sanitize_text_field( $_POST['company_logo'][ $key ] );
		$wpdb->insert(
			$wpdb->prefix . 'evs_voting_options',
			array(
				'form_id'      => $form_id,
				'company_name' => sanitize_text_field( $name ),
				'company_logo' => $logo
			)
		);
	}
}

// Handle delete form
if ( isset( $_GET['delete_form'] ) ) {
	$form_id = intval( $_GET['delete_form'] );
	$wpdb->delete( $wpdb->prefix . 'evs_voting_forms', array( 'id' => $form_id ) );
}

$forms = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}evs_voting_forms" );
?>
<div class="wrap">
	<h1 class="wp-heading-inline">Voting Options</h1>
	<button type="button" id="create-new-form" class="page-title-action">Add New Form</button>

	<!-- Create new form -->
	<div class="postbox" id="postbox" style="display: none;">
		<h2>Create New Voting Form</h2>
		<form method="post" id="create-form">
			<p>
				<label>Form Name:</label>
				<input type="text" name="form_name" required class="regular-text">
			</p>

            <p>
				<label>Message Lavel:</label>
				<input type="text" name="message_lavel" required class="regular-text">
			</p>

			<div id="company-options">
				<div class="company-option">
					<div class="company-header">
						<h4>Company Option</h4>
						<button type="button" class="delete-company button button-link-delete">
							<span class="dashicons dashicons-trash"></span>
						</button>
					</div>
					<p>
						<label>Company Name:</label>
						<input type="text" name="company_name[]" required class="regular-text">
					</p>
					<p>
						<label>Company Logo:</label>
						<input type="hidden" name="company_logo[]" class="company-logo-url" required>
						<img src="" class="company-logo-preview" style="display:none; max-width:200px; margin-top:10px;">
						<button type="button" class="upload-logo-btn button">Upload Logo</button>
					</p>
				</div>
			</div>

			<p>
				<button type="button" id="add-company-option" class="button button-secondary add-company-option">
					<span class="dashicons dashicons-plus-alt2"></span> Add Another Company
				</button>
			</p>

			<input type="submit" name="create_form" class="button button-primary" value="Create Form">
		</form>
	</div>
	<!-- Existing forms -->
	<h2>Existing Voting Forms</h2>
	<?php foreach ( $forms as $form ) : ?>
		<div class="postbox">
			<h3>
				<?php echo esc_html( $form->form_name ); ?>
				<small>[event_voting_form id="<?php echo $form->id; ?>"]</small>
				<a href="?page=evs-voting-options&delete_form=<?php echo $form->id; ?>"
					class="button button-small button-link-delete" onclick="return confirm('Are you sure?')">Delete</a>
			</h3>
            <p>Message Lavel: <?php echo esc_html( $form->message_lavel );?></p>
			<?php
			$options = $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}evs_voting_options WHERE form_id = %d",
				$form->id
			) );
			?>
			<table class="widefat">
				<thead>
					<tr>
						<th>SL</th>
						<th>Logo</th>
						<th>Company Name</th>
					</tr>
				</thead>
				<tbody>
					<?php
                    $i = 1;
                    foreach ( $options as $option ) : ?>
						<tr>
                            <td><?php echo $i++; ?></td>
							<td><img src="<?php echo esc_url( $option->company_logo ); ?>" height="50"></td>
							<td><?php echo esc_html( $option->company_name ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endforeach; ?>
</div>

<script>
	// function addCompanyOption() {
	// 	const div = document.createElement('div');
	// 	div.className = 'company-option';
	// 	div.innerHTML = `
	// 	<p>
	// 		<label>Company Name:</label>
	// 		<input type="text" name="company_name[]" required>
	// 		<label>Logo URL:</label>
	// 		<input type="url" name="company_logo[]" required>
	// 	</p>
	// `;
	// 	document.getElementById('company-options').appendChild(div);
	// }
</script>