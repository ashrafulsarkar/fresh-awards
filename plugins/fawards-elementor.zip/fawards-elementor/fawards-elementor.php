<?php
/**
 * Plugin Name: Fresh Awards Elementor Addon
 * Description: Custom Elementor addon For Fresh Awards Theme.
 * Plugin URI:  https://github.com/ashrafulsarkar
 * Version:     1.0.0
 * Author:      Ashraful Sarkar Naiem
 * Author URI:  https://github.com/ashrafulsarkar
 * Text Domain: fawardsp
 * 
 * Elementor tested up to: 3.26.5
 * Elementor Pro tested up to: 3.26.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
define( 'FAWARDS_ELEMENTOR_URL', plugin_dir_url(__FILE__) );
define( 'FAWARDS_ELEMENTOR_CSS', FAWARDS_ELEMENTOR_URL .'assets/css' );
define( 'FAWARDS_ELEMENTOR_JS', FAWARDS_ELEMENTOR_URL .'assets/js' );

function fawards_elementor_addon() {
	require_once( __DIR__ . '/includes/plugin.php' );
	load_plugin_textdomain('fawardsp', false, dirname(__FILE__) . "/languages");

	\Fawards_Elementor_Addon\Plugin::instance();
}
add_action( 'plugins_loaded', 'FAWARDS_ELEMENTOR_addon' );