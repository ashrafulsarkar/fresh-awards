<?php
namespace Fawards_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Judges_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'fawards_judges';
	}

	public function get_title() {
		return esc_html__( 'Fresh Awards Judges', 'fawardsp' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel fawards_elementor_panel';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_keywords() {
		return [ 'judges', 'awards', 'fresh' ];
	}

	public function get_script_depends() {
		return ['jquery'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Judges', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Judges Image', 'fawardsp' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'name',
			[
				'label'       => esc_html__( 'Name', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'BEST PLACE TO WORK' ),
			]
		);

		$this->add_control(
			'short_desc',
			[
				'label'       => esc_html__( 'Short Description', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
			]
		);

		$this->add_control(
			'description_title',
			[
				'label'       => esc_html__( 'Description Title', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::WYSIWYG,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_details_style',
			[
				'label' => esc_html__( 'Content Style', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_border_redius',
			[
				'label'      => esc_html__( 'Image Border Redius', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'   => [
					'size'	=>	30,
					'unit'	=> 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__image img' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .fawards-judges__content h3',
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Name Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__content h3' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'name_space',
			[
				'label'      => esc_html__( 'Name Space', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'   => [
					'size'	=>	10,
					'unit'	=> 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__content h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'name_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'short_d_typography',
				'selector' => '{{WRAPPER}} .fawards-judges__content p',
			]
		);

		$this->add_control(
			'short_d_color',
			[
				'label'     => esc_html__( 'Short Description Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__content p' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'short_d_space',
			[
				'label'      => esc_html__( 'Short Description Space', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'   => [
					'size'	=>	10,
					'unit'	=> 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'full_d_details_style',
			[
				'label' => esc_html__( 'Full Desctiption Style', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'box_bg_color',
			[
				'label'     => esc_html__( 'Box Background Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__full-description' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => esc_html__( 'Box Padding', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default' => [
					'top' => 50,
					'right' => 50,
					'bottom' => 50,
					'left' => 50,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__full-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_margin',
			[
				'label'      => esc_html__( 'Box Margin', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default' => [
					'top' => 30,
					'right' => 0,
					'bottom' => 0,
					'left' => 0,
					'unit' => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__full-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// border redius
		$this->add_responsive_control(
			'box_border_radius',
			[
				'label'      => esc_html__( 'Box Border Redius', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default' => [
					'top' => 30,
					'right' => 30,
					'bottom' => 30,
					'left' => 30,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__full-description' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'box_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'full_d_title_typography',
				'selector' => '{{WRAPPER}} .fawards-judges__full-description h3',
			]
		);

		$this->add_control(
			'full_d_color',
			[
				'label'     => esc_html__( 'Full Desctiption Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__full-description h3' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'full_d_space',
			[
				'label'      => esc_html__( 'Full Desctiption Title Space', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'   => [
					'size'	=>	10,
					'unit'	=> 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__full-description h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'full_d_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'full_d_typography',
				'selector' => '{{WRAPPER}} .fawards-judges__full-description p',
			]
		);

		$this->add_control(
			'full_d_text_color',
			[
				'label'     => esc_html__( 'Full Desctiption Text Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .fawards-judges__full-description p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$fawards_judges_id = $this->get_id();
		?>
		<div class="fawards-judges">
			<div class="row align-items-center">
				<div class="col-md-6">
					<div class="fawards-judges__image">
						<img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['name'] ); ?>">
					</div>
				</div>
				<div class="col-md-6">
					<div class="fawards-judges__content">
						<h3><?php echo $settings['name']; ?></h3>
						<p><?php echo esc_html( $settings['short_desc'] ); ?></p>
						<button class="fawards_judges_btn" id="fawards_judges_btn_<?php echo esc_attr( $fawards_judges_id ); ?>">Read More</button>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="fawards-judges__full-description full_description_<?php echo esc_attr( $fawards_judges_id ); ?>" style="display: none;">
						<h3><?php echo esc_html($settings['description_title'])?></h3>
						<p><?php echo wp_kses_post( $settings['description'] ); ?></p>
					</div>
				</div>
			</div>
		</div>
		<script>
			jQuery( document ).ready( function( $) {
				$( '#fawards_judges_btn_<?php echo esc_attr( $fawards_judges_id ); ?>' ).on( 'click', function() {
					$( '.full_description_<?php echo esc_attr( $fawards_judges_id ); ?>' ).slideToggle();
					let text = $( this ).text() == 'Read More' ? 'Close' : 'Read More';
					$( this ).text( text );
					$( this ).toggleClass( 'open' );
				});
			});
		</script>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}