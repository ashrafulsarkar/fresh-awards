<?php
namespace Fawards_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Slider_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'fawards_slider';
	}

	public function get_title() {
		return esc_html__( 'Fresh Awards Slider', 'fawardsp' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel fawards_elementor_panel';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_keywords() {
		return [ 'slider', 'slider', 'carousel' ];
	}

	public function get_style_depends() {
		return ['fawards-elementor-slick'];
	}

	public function get_script_depends() {
		return ['jquery', 'fawards-elementor-slick'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Slider', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		/* Start repeater */

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'fawardsp' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'logo',
			[
				'label'   => esc_html__( 'Choose Logo', 'fawardsp' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'BEST PLACE TO WORK' ),
			]
		);

		$repeater->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .slider_item h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'slider_items',
			[
				'label'       => esc_html__( 'Slider Items', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(), /* Use our repeater */
				'default' => [
					[
						'title' => esc_html__( 'BEST PLACE TO WORK', 'fawardsp' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_option',
			[
				'label' => esc_html__( 'Slider Option', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_infinite',
			[
				'label'        => esc_html__( 'Infinite', 'fawardsp' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'True', 'fawardsp' ),
				'label_off'    => esc_html__( 'False', 'fawardsp' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'fawardsp' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'True', 'fawardsp' ),
				'label_off'    => esc_html__( 'False', 'fawardsp' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_details_style',
			[
				'label' => esc_html__( 'Content Style', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .slider_item h3',
			]
		);

		$this->add_responsive_control(
			'slider_height',
			[
				'label'      => esc_html__( 'Slider Height', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'default'   => [
					'size'	=>	400,
					'unit'	=> 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .slider_item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Image Width', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'   => [
					'size'	=>	240,
					'unit'	=> 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .slider_image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$fawards_slider_id = $this->get_id();
		?>
		<div class="fawards-slider fawards_slider_active_<?php echo $fawards_slider_id;?>">
			<?php
			foreach ( $settings['slider_items'] as $index => $item ) { ?>
			<div class="slider_item" style="background-image: url(<?php echo $item['image']['url']?>);">
				<div class="slider_details">
					<?php 
					$img_url = $item['logo']['url'];
					if (!empty($img_url)) { ?>
						<div class="slider_image">
							<img src="<?php echo $img_url?>">
						</div>
					<?php } ?>

					<?php
					$item_title = $item['title'];
					if (!empty($item_title)) { ?>
						<h3><?php echo $item['title'];?></h3>
					<?php } ?>
				</div>
			</div>
			<?php } ?>
		</div>
		<script>
			<?php
			
			$infinite = $settings['show_infinite'];
			$autoplay = $settings['show_autoplay'];


			$fawards_infinite = 'false';
			if ($infinite) {
				$fawards_infinite = 'true';
			}

			$fawards_autoplay = 'false';
			if ($autoplay) {
				$fawards_autoplay = 'true';
			}

			?>
			jQuery( document ).ready( function( $) {
				$('.fawards_slider_active_<?php echo $fawards_slider_id;?>').slick({
					dots: true,
					arrows: true,
					infinite: <?php echo $fawards_infinite;?>,
					autoplay: <?php echo $fawards_autoplay;?>,
					slidesToShow: 1,
					slidesToScroll: 1,
					prevArrow: '<button type="button" class="slick-prev"><i class="fa-solid fa-chevron-left"></i></button>',
					nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-chevron-right"></i></button>',
					responsive: [
						{
						breakpoint: 1024,
							
						},
					]

				});
			});
		</script>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}