<?php
namespace Fawards_Elementor_Addon;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Vote_Tabs extends Widget_Base {
    public function get_name() {
        return 'vote_tabs';
    }

    public function get_title() {
        return __('Vote Tabs', 'plugin-name');
    }

    public function get_icon() {
        return 'eicon-tabs';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_tabs',
            [
                'label' => __('Tabs', 'plugin-name'),
            ]
        );

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
            'tab_image',
			[
				'label' => __('Image', 'plugin-name'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

        $repeater->add_control(
            'tab_title',
            [
                'label' => __('Sponsored Title', 'plugin-name'),
                'type' => Controls_Manager::TEXT,
                'default' => __('IFCO', 'plugin-name'),
            ]
        );

        $repeater->add_control(
            'title_1',
            [
                'label' => __('Title 1', 'plugin-name'),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'title_2',
            [
                'label' => __('Title 2', 'plugin-name'),
                'type' => Controls_Manager::TEXT,
            ]
        );

        //$repeater for shortcode
		$repeater->add_control(
			'tab_shortcode',
			[
				'label' => __('Shortcode', 'plugin-name'),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __('[event_voting_form id="1"]', 'plugin-name'),
			]
		);

		$repeater->add_control(
            'hide_class',
            [
                'label' => __('Hide Class', 'plugin-name'),
                'type' => Controls_Manager::TEXT,
				'default' => 'vote_hide_1',
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => __('Tab Items', 'plugin-name'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tab_title' => __('Sponsored Title 1', 'plugin-name'),
                    ],
                    [
                        'tab_title' => __('Sponsored Title 2', 'plugin-name'),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="custom-tabs">
			<div class="tabs_items">
				<ul class="tab-titles">
					<?php foreach ($settings['tabs'] as $index => $tab) : ?>
						<li class="tab-title" data-tab="tab-<?php echo $index; ?>">
							<div>
                                <?php if (!empty($tab['tab_image']['url'])) : ?>
                                    <img src="<?php echo esc_url($tab['tab_image']['url']); ?>" alt="<?php echo esc_attr($tab['tab_title']); ?>">
                                <?php endif; ?>
                                <p><?php echo esc_html($tab['tab_title']); ?></p>
                            </div>
							<button>Vote Now</button>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
            <div class="tab-contents">
                <?php foreach ($settings['tabs'] as $index => $tab) : ?>
                    <div id="tab-<?php echo $index; ?>" class="tab-content">
						<h4 class="title_1 <?php echo esc_html($tab['hide_class']) ?>"><?php echo esc_html($tab['title_1']) ?></h4>
						<h3 class="title_2 <?php echo esc_html($tab['hide_class']) ?>"><?php echo esc_html($tab['title_2']) ?></h3>
                        <?php echo do_shortcode($tab['tab_shortcode']); ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <script>
			jQuery(document).ready(function($) {
				let $tabs = $(".tab-title");
				let $contents = $(".tab-content");
				
				if ($tabs.length > 0) {
					$tabs.first().addClass("active");
					$contents.first().addClass("active");
				}
				
				$tabs.on("click", function() {
					let index = $(this).index();
					$tabs.removeClass("active");
					$contents.removeClass("active");
					
					$(this).addClass("active");
					$contents.eq(index).addClass("active");
				});
			});
        </script>
        <?php
    }

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}