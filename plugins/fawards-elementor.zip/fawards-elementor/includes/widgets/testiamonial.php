<?php
namespace Fawards_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Testiamonial_Slider_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'fawards_testiamonial_slider';
	}

	public function get_title() {
		return esc_html__( 'Testaimonial Slider', 'fawardsp' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel fawards_elementor_panel';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_keywords() {
		return [ 'slider', 'testiamonial', 'carousel', 'image box' ];
	}

	public function get_style_depends() {
		return ['fawards-elementor-slick'];
	}

	public function get_script_depends() {
		return ['jquery', 'fawards-elementor-slick'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Slider', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		/* Start repeater */

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'fawardsp' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'BEST PLACE TO WORK' ),
			]
		);

		$repeater->add_control(
			'winner_title',
			[
				'label'       => esc_html__( 'Winner Title', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( '2024 winner:' ),
			]
		);

		$repeater->add_control(
			'winner_text',
			[
				'label'       => esc_html__( 'Winner Text', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'ALDI' ),
			]
		);

		$repeater->add_control(
			'comment_title',
			[
				'label'       => esc_html__( 'Comment Title', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Judges comment:' ),
			]
		);

		$repeater->add_control(
			'comment',
			[
				'label'       => esc_html__( 'Comment', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'placeholder' => esc_html__( 'Type comment here', 'fawardsp' ),
			]
		);

		$this->add_control(
			'testiamonial_items',
			[
				'label'       => esc_html__( 'Slider Items', 'fawardsp' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(), /* Use our repeater */
				'default' => [
					[
						'title' => esc_html__( 'BEST PLACE TO WORK', 'fawardsp' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_option',
			[
				'label' => esc_html__( 'Slider Option', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_infinite',
			[
				'label'        => esc_html__( 'Infinite', 'fawardsp' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'True', 'fawardsp' ),
				'label_off'    => esc_html__( 'False', 'fawardsp' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'fawardsp' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'True', 'fawardsp' ),
				'label_off'    => esc_html__( 'False', 'fawardsp' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_details_style',
			[
				'label' => esc_html__( 'Content Style', 'fawardsp' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .testiamonial_item h3',
			]
		);

		$this->add_responsive_control(
			'title_space',
			[
				'label'      => esc_html__( 'Space', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item h3' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'winner_title_color',
			[
				'label'     => esc_html__( 'Winner Title Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#282828',
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item h5' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'winner_title_typography',
				'selector' => '{{WRAPPER}} .testiamonial_item h5',
			]
		);

		$this->add_responsive_control(
			'winner_title_space',
			[
				'label'      => esc_html__( 'Space', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item h5' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'winner_title_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'winner_text_color',
			[
				'label'     => esc_html__( 'Winner Text Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#282828',
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item p.winner_text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'winner_text_typography',
				'selector' => '{{WRAPPER}} .testiamonial_item p.winner_text',
			]
		);

		$this->add_responsive_control(
			'winner_text_space',
			[
				'label'      => esc_html__( 'Space', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item p.winner_text' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'winner_text_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'comment_title_color',
			[
				'label'     => esc_html__( 'Comment Title Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#282828',
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'comment_title_typography',
				'selector' => '{{WRAPPER}} .testiamonial_item h4',
			]
		);

		$this->add_responsive_control(
			'comment_title_space',
			[
				'label'      => esc_html__( 'Space', 'fawardsp' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item h4' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'comment_title_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);


		$this->add_control(
			'comment_color',
			[
				'label'     => esc_html__( 'Comment Color', 'fawardsp' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#282828',
				'selectors' => [
					'{{WRAPPER}} .testiamonial_item p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'comment_typography',
				'selector' => '{{WRAPPER}} .testiamonial_item p',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$fawards_slider_id = $this->get_id();
		?>
		<div class="fawards-testiamonial-slider fawards_testiamonial_active_<?php echo $fawards_slider_id;?>">
			<?php
			foreach ( $settings['testiamonial_items'] as $index => $item ) { ?>
			<div class="testiamonial_item">
				<div class="row gap-40">
					<div class="col-md-6">
						<div class="testiamonial_image">
							<?php 
							$img_url = $item['image']['url'];
							if (!empty($img_url)) { ?>
								<img src="<?php echo $img_url?>">
							<?php } ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="testimonial_details">
							<h3><?php echo $item['title'];?></h3>
							<h5><?php echo $item['winner_title'];?></h5>
							<p class="winner_text"><?php echo $item['winner_text'];?></p>
							<h4><?php echo $item['comment_title'];?></h4>
							<p><?php echo $item['comment'];?></p>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
		<script>
			<?php
			
			$infinite = $settings['show_infinite'];
			$autoplay = $settings['show_autoplay'];


			$fawards_infinite = 'false';
			if ($infinite) {
				$fawards_infinite = 'true';
			}

			$fawards_autoplay = 'false';
			if ($autoplay) {
				$fawards_autoplay = 'true';
			}

			?>
			jQuery( document ).ready( function( $) {
				$('.fawards_testiamonial_active_<?php echo $fawards_slider_id;?>').slick({
					dots: true,
					arrows: true,
					infinite: <?php echo $fawards_infinite;?>,
					autoplay: <?php echo $fawards_autoplay;?>,
					slidesToShow: 1,
					slidesToScroll: 1,
					prevArrow: '<button type="button" class="slick-prev"><i class="fa-solid fa-chevron-left"></i></button>',
					nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-chevron-right"></i></button>',
					responsive: [
						{
						breakpoint: 1024,
							
						},
					]

				});
			});
		</script>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}