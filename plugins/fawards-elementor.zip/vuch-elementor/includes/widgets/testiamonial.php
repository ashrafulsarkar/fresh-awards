<?php
namespace Vuch_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Testiamonial_Slider_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'vuch_testiamonial_slider';
	}

	public function get_title() {
		return esc_html__( 'Testaimonial Slider', 'vuch-elementor' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel vuch_elementor_panel';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_keywords() {
		return [ 'slider', 'testiamonial', 'carousel', 'image box' ];
	}

	public function get_style_depends() {
		return ['vuch-elementor-slick'];
	}

	public function get_script_depends() {
		return ['jquery', 'vuch-elementor-slick'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Slider', 'vuch-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		/* Start repeater */

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'vuch-elementor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'name',
			[
				'label'       => esc_html__( 'Name', 'vuch-elementor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Ashraful Sarkar' ),
				'placeholder' => esc_html__( 'Type your title here', 'vuch-elementor' ),
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vuch-elementor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'President at TEDxFHNW' ),
				'placeholder' => esc_html__( 'Type your title here', 'vuch-elementor' ),
			]
		);

		$repeater->add_control(
			'item_description',
			[
				'label'       => esc_html__( 'Description', 'vuch-elementor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => esc_html__( 'Wir alle haben Anspruch auf ein sicheres und lebenswertes Umfeld. Es braucht jedoch Menschen wie Sie, die ihr ganzes Wesen für die Sicherheit Dritter einsetzen, zuverlässig und verschwiegen sind. Gemeinsam mit uns und unseren Mitarbeitern schützen und sichern Sie die wichtigen Dinge unserer Mitmenschen.' ),
				'placeholder' => esc_html__( 'Type your description here', 'vuch-elementor' ),
			]
		);

		

		/* End repeater */

		$this->add_control(
			'slider_2_items',
			[
				'label'       => esc_html__( 'Slider Items', 'vuch-elementor' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(), /* Use our repeater */
				'default' => [
					[
						'name' => esc_html__( 'Ashraful Sarkar', 'vuch-elementor' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_option',
			[
				'label' => esc_html__( 'Slider Option', 'vuch-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'slides_show',
			[
				'label'   => esc_html__( 'Slides Show', 'vuch-elementor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => [
					'1' => esc_html__( '1', 'vuch-elementor' ),
					'2' => esc_html__( '2', 'vuch-elementor' ),
					'3' => esc_html__( '3', 'vuch-elementor' ),
					'4' => esc_html__( '4', 'vuch-elementor' ),
					'5' => esc_html__( '5', 'vuch-elementor' ),
				],
			]
		);

		$this->add_control(
			'slides_scroll',
			[
				'label'     => esc_html__( 'Slides Scroll', 'vuch-elementor' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => '1',
				'options'   => [
					'1' => esc_html__( '1', 'vuch-elementor' ),
					'2' => esc_html__( '2', 'vuch-elementor' ),
					'3' => esc_html__( '3', 'vuch-elementor' ),
				],
				'condition' => [
					'slides_show!' => '1',
				],
			]
		);

		$this->add_control(
			'show_arrows',
			[
				'label'        => esc_html__( 'Show Arrow', 'vuch-elementor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'vuch-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'vuch-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_infinite',
			[
				'label'        => esc_html__( 'Infinite', 'vuch-elementor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'True', 'vuch-elementor' ),
				'label_off'    => esc_html__( 'False', 'vuch-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'vuch-elementor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'True', 'vuch-elementor' ),
				'label_off'    => esc_html__( 'False', 'vuch-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'style_content_section',
			[
				'label' => esc_html__( 'Content Box', 'vuch-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'box_bg',
			[
				'label'     => esc_html__( 'Background', 'vuch-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ECF4FF',
				'selectors' => [
					'{{WRAPPER}} .vuch_slider_items' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => esc_html__( 'Box Padding', 'vuch-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '20',
					'right'  => '20',
					'bottom' => '20',
					'left'   => '20',
				],
				'selectors'  => [
					'{{WRAPPER}} .vuch_slider_items' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'box_height',
			[
				'type' => \Elementor\Controls_Manager::SLIDER,
				'label' => esc_html__( 'Box Height', 'vuch-elementor' ),
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .slider_2_item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_details_style',
			[
				'label' => esc_html__( 'Content Style', 'vuch-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Name Color', 'vuch-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#282828',
				'selectors' => [
					'{{WRAPPER}} .slider_2_item h5' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .slider_2_item h5',
			]
		);

		$this->add_responsive_control(
			'name_text_align',
			[
				'label' => esc_html__( 'Alignment', 'vuch-elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .slider_2_item h5' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'name_space',
			[
				'label'      => esc_html__( 'Space', 'vuch-elementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .slider_2_item h5' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'vuch-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#282828',
				'selectors' => [
					'{{WRAPPER}} .slider_2_item h6' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .slider_2_item h6',
			]
		);

		$this->add_responsive_control(
			'title_text_align',
			[
				'label' => esc_html__( 'Alignment', 'vuch-elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .slider_2_item h6' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'name_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);


		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Description Color', 'vuch-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#282828',
				'selectors' => [
					'{{WRAPPER}} .slider_2_item p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .slider_2_item p',
			]
		);

		$this->add_responsive_control(
			'content_text_align',
			[
				'label' => esc_html__( 'Alignment', 'vuch-elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'vuch-elementor' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .slider_2_item p' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$vuch_slider_id = $this->get_id();
		?>
		<div class="vuch-testiamonial-slider vuch_testiamonial_active_<?php echo $vuch_slider_id;?>">
			<?php
			foreach ( $settings['slider_2_items'] as $index => $item ) { ?>
			<div class="slider_2_item">
				<div class="vuch_slider_items">
					<p><?php echo $item['item_description'];?></p>
					<div class="slider_profile_info">
						<div class="slider_2_image">
							<?php 
							$img_url = $item['image']['url'];
							if (!empty($img_url)) { ?>
								<img src="<?php echo $img_url?>">
							<?php } ?>
						</div>
						<div class="slider_person_details">
							<h5><?php echo $item['name'];?></h5>
							<h6><?php echo $item['title'];?></h6>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
		<script>
			<?php
			$show_arrows = $settings['show_arrows'];
			$infinite = $settings['show_infinite'];
			$autoplay = $settings['show_autoplay'];
			$slides_show = $settings['slides_show'];
			$slides_scroll = $settings['slides_scroll'];

			$vuch_arrows = 'false';
			if ($show_arrows) {
				$vuch_arrows = 'true';
			}

			$vuch_infinite = 'false';
			if ($infinite) {
				$vuch_infinite = 'true';
			}

			$vuch_autoplay = 'false';
			if ($autoplay) {
				$vuch_autoplay = 'true';
			}

			?>
			jQuery( document ).ready( function( $) {
				$('.vuch_testiamonial_active_<?php echo $vuch_slider_id;?>').slick({
					dots: false,
					arrows: <?php echo $vuch_arrows;?>,
					infinite: <?php echo $vuch_infinite;?>,
					autoplay: <?php echo $vuch_autoplay;?>,
					slidesToShow: <?php echo $slides_show;?>,
					slidesToScroll: <?php echo $slides_scroll;?>,
					prevArrow: '<button type="button" class="slick-prev"><i class="fa-solid fa-chevron-left"></i></button>',
					nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-chevron-right"></i></button>',
					responsive: [
						{
						breakpoint: 1024,
							settings: {
								slidesToShow: 2,
							}
						},
						{
						breakpoint: 650,
							settings: {
								slidesToShow: 1,
							}
						}
					]

				});
			});
		</script>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}