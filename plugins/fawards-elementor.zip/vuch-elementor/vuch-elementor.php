<?php
/**
 * Plugin Name: Vuch Elementor Addon
 * Description: Custom Elementor addon For Vuch Theme.
 * Plugin URI:  https://github.com/ashrafulsarkar
 * Version:     1.0.0
 * Author:      Ashraful Sarkar Naiem
 * Author URI:  https://github.com/ashrafulsarkar
 * Text Domain: vuch-elementor
 * 
 * Elementor tested up to: 3.7.0
 * Elementor Pro tested up to: 3.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
define( 'VUCH_ELEMENTOR_URL', plugin_dir_url(__FILE__) );
define( 'VUCH_ELEMENTOR_CSS', VUCH_ELEMENTOR_URL .'assets/css' );
define( 'VUCH_ELEMENTOR_JS', VUCH_ELEMENTOR_URL .'assets/js' );

function vuch_elementor_addon() {
	require_once( __DIR__ . '/includes/plugin.php' );
	load_plugin_textdomain("vuch-elementor", false, dirname(__FILE__) . "/languages");

	\Vuch_Elementor_Addon\Plugin::instance();
}
add_action( 'plugins_loaded', 'vuch_elementor_addon' );